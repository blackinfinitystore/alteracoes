#!/usr/bin/env python3
# Bot Discord de salas + painel. Config: config.json (editável no painel).
# python bot.py

from __future__ import annotations

import hashlib
import json
import os
import random
import secrets
import string
import time
from pathlib import Path

import aiohttp
from aiohttp import web
import discord
from discord import app_commands
from discord.ext import commands

ROOT = Path(__file__).resolve().parent
CFG_PATH = ROOT / "config.json"
SALDO_PATH = ROOT / "data" / "saldos.json"
SALDO_PATH.parent.mkdir(parents=True, exist_ok=True)

CFG: dict = {}
PEDIDOS: dict[str, dict] = {}
PANEL_SESS: set[str] = set()
MODOS = {
    "cs": {"label": "CS Rank 4v4", "game_mode": 15, "map_id": 1, "max_players": 8, "group_mode": 3},
    "br": {"label": "BR Classic", "game_mode": 1, "map_id": 1, "max_players": 50, "group_mode": 0},
}


def load_cfg() -> dict:
    with CFG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_cfg(cfg: dict):
    tmp = CFG_PATH.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
        f.write("\n")
    tmp.replace(CFG_PATH)


def apply_cfg(cfg: dict):
    global CFG
    CFG = cfg
    owners = cfg.get("owners") or []
    oid = cfg.get("owner_id")
    if oid and str(oid) not in [str(x) for x in owners]:
        owners = [str(oid)] + [str(x) for x in owners]
    CFG["owners"] = [str(x).strip() for x in owners if str(x).strip()]


def owners() -> set[int]:
    out = set()
    for x in CFG.get("owners") or []:
        try:
            out.add(int(str(x).strip()))
        except Exception:
            pass
    return out


def is_owner(user) -> bool:
    try:
        return int(user.id) in owners()
    except Exception:
        return False


def pix() -> dict:
    return CFG.get("pix") or {}


def pix_valor() -> float:
    try:
        return float(pix().get("valor") or 0)
    except Exception:
        return 0.0


def tcp_api() -> str:
    return str(CFG.get("tcp_api") or "http://127.0.0.1:7744").rstrip("/")


def tcp_secret() -> str:
    return str(CFG.get("tcp_secret") or "")


def load_saldos() -> dict:
    if not SALDO_PATH.exists():
        return {}
    try:
        return json.loads(SALDO_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_saldos(d: dict):
    SALDO_PATH.write_text(json.dumps(d, indent=2), encoding="utf-8")


def get_saldo(uid: int) -> float:
    try:
        return float(load_saldos().get(str(uid)) or 0)
    except Exception:
        return 0.0


def set_saldo(uid: int, valor: float) -> float:
    d = load_saldos()
    d[str(uid)] = round(float(valor), 2)
    save_saldos(d)
    return d[str(uid)]


def add_saldo(uid: int, delta: float) -> float:
    return set_saldo(uid, get_saldo(uid) + delta)


def emv(tag: str, value: str) -> str:
    return f"{tag}{len(value):02d}{value}"


def crc16(data: str) -> str:
    crc = 0xFFFF
    for ch in data.encode("utf-8"):
        crc ^= ch << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return f"{crc:04X}"


def pix_copia_cola(txid: str) -> str:
    p = pix()
    chave = str(p.get("chave") or "").strip()
    nome = str(p.get("nome") or "RZIM")[:25]
    cidade = str(p.get("cidade") or "SAO PAULO")[:15]
    gui = emv("00", "br.gov.bcb.pix") + emv("01", chave)
    merchant = emv("26", gui)
    extra = emv("05", txid[:25])
    add = emv("62", extra)
    payload = emv("00", "01") + emv("01", "12") + merchant + emv("52", "0000") + emv("53", "986")
    v = pix_valor()
    if v > 0:
        payload += emv("54", f"{v:.2f}")
    payload += emv("58", "BR") + emv("59", nome) + emv("60", cidade) + add + "6304"
    return payload + crc16(payload)


def novo_txid() -> str:
    return "RZ" + "".join(random.choices(string.ascii_uppercase + string.digits, k=10))


async def tcp_json(method: str, path: str, body: dict | None = None):
    headers = {"X-Bot-Secret": tcp_secret(), "Content-Type": "application/json"}
    async with aiohttp.ClientSession() as sess:
        async with sess.request(method, tcp_api() + path, headers=headers, json=body, timeout=aiohttp.ClientTimeout(total=8)) as r:
            text = await r.text()
            try:
                data = json.loads(text) if text else {}
            except Exception:
                data = {"raw": text}
            if r.status >= 400:
                raise RuntimeError(data.get("error") or f"HTTP {r.status}")
            return data


async def criar_sala_tcp(modo: str, quem: str) -> dict:
    spec = MODOS[modo]
    return await tcp_json("POST", "/bot/rooms", {
        "name": f"Discord · {quem}"[:40],
        "game_mode": spec["game_mode"],
        "map_id": spec["map_id"],
        "max_players": spec["max_players"],
        "group_mode": spec["group_mode"],
    })


def embed_sala(sala: dict, modo: str) -> discord.Embed:
    spec = MODOS.get(modo) or {}
    e = discord.Embed(title="Sala criada", color=0xE50914)
    e.add_field(name="Modo", value=spec.get("label") or modo.upper(), inline=True)
    e.add_field(name="ID da sala", value=f"`{sala.get('id')}`", inline=True)
    e.add_field(name="Senha", value=f"`{sala.get('password')}`", inline=True)
    e.add_field(name="Jogadores", value=f"{sala.get('players', 0)}/{sala.get('max_players', 0)}", inline=True)
    e.set_footer(text="No jogo: Salas → busca pelo ID → senha. Quem entra primeiro vira o dono e dá o start.")
    return e


async def avisos_donos(client: discord.Client, texto: str, view=None):
    for oid in owners():
        try:
            u = client.get_user(oid) or await client.fetch_user(oid)
            await u.send(texto, view=view)
        except Exception:
            pass


class PedidoView(discord.ui.View):
    def __init__(self, pedido_id: str):
        super().__init__(timeout=30 * 60)
        self.pedido_id = pedido_id

    @discord.ui.button(label="Já paguei", style=discord.ButtonStyle.success)
    async def paguei(self, interaction: discord.Interaction, _: discord.ui.Button):
        ped = PEDIDOS.get(self.pedido_id)
        if not ped:
            await interaction.response.send_message("Pedido expirado.", ephemeral=True)
            return
        if interaction.user.id != ped["user_id"] and not is_owner(interaction.user):
            await interaction.response.send_message("Esse PIX não é seu.", ephemeral=True)
            return
        await interaction.response.send_message("Aviso enviado aos donos. Espera a liberação.", ephemeral=True)
        await avisos_donos(
            interaction.client,
            f"PIX de <@{ped['user_id']}> · **{MODOS[ped['modo']]['label']}** · R${pix_valor():.2f}\nPedido `{self.pedido_id}`",
            LiberarView(self.pedido_id),
        )

    @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.secondary)
    async def cancelar(self, interaction: discord.Interaction, _: discord.ui.Button):
        ped = PEDIDOS.get(self.pedido_id)
        if not ped or (interaction.user.id != ped["user_id"] and not is_owner(interaction.user)):
            await interaction.response.send_message("Não dá pra cancelar.", ephemeral=True)
            return
        PEDIDOS.pop(self.pedido_id, None)
        await interaction.response.send_message("Pedido cancelado.", ephemeral=True)


class LiberarView(discord.ui.View):
    def __init__(self, pedido_id: str):
        super().__init__(timeout=30 * 60)
        self.pedido_id = pedido_id

    @discord.ui.button(label="Liberar sala", style=discord.ButtonStyle.danger)
    async def liberar(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_owner(interaction.user):
            await interaction.response.send_message("Só dono libera.", ephemeral=True)
            return
        ped = PEDIDOS.pop(self.pedido_id, None)
        if not ped:
            await interaction.response.send_message("Pedido já usado ou expirou.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            user = interaction.client.get_user(ped["user_id"]) or await interaction.client.fetch_user(ped["user_id"])
            nome = user.display_name if user else str(ped["user_id"])
            sala = await criar_sala_tcp(ped["modo"], nome)
        except Exception as e:
            PEDIDOS[self.pedido_id] = ped
            await interaction.followup.send(f"Falha no TCP: {e}", ephemeral=True)
            return
        emb = embed_sala(sala, ped["modo"])
        await interaction.followup.send("Sala liberada.", ephemeral=True)
        if user:
            try:
                await user.send(embed=emb)
            except Exception:
                pass
        ch = interaction.client.get_channel(ped.get("channel_id") or 0)
        if isinstance(ch, discord.abc.Messageable):
            await ch.send(content=f"<@{ped['user_id']}> sala paga liberada.", embed=emb)


intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    nome = str(CFG.get("bot_name") or "").strip()
    if nome and bot.user and bot.user.name != nome:
        try:
            await bot.user.edit(username=nome)
        except Exception as e:
            print("username:", e)
    try:
        synced = await bot.tree.sync()
        print(f"Bot online {bot.user} · {len(synced)} comandos")
    except Exception as e:
        print("sync:", e)
    if not getattr(bot, "_panel_started", False):
        bot._panel_started = True
        bot.loop.create_task(start_panel())


@bot.tree.error
async def on_app_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        if not interaction.response.is_done():
            await interaction.response.send_message("Só dono do bot usa isso.", ephemeral=True)
        return
    raise error


def owner_only():
    async def pred(interaction: discord.Interaction) -> bool:
        return is_owner(interaction.user)
    return app_commands.check(pred)


@bot.tree.command(name="sala", description="Pedir sala CS ou BR (saldo ou PIX)")
@app_commands.describe(modo="cs = 4v4 · br = classic")
@app_commands.choices(modo=[
    app_commands.Choice(name="CS 4v4", value="cs"),
    app_commands.Choice(name="BR", value="br"),
])
async def cmd_sala(interaction: discord.Interaction, modo: app_commands.Choice[str]):
    m = modo.value
    preco = pix_valor()
    saldo = get_saldo(interaction.user.id)
    if preco > 0 and saldo >= preco:
        await interaction.response.defer(ephemeral=True)
        try:
            sala = await criar_sala_tcp(m, interaction.user.display_name)
        except Exception as e:
            await interaction.followup.send(f"TCP fora: {e}", ephemeral=True)
            return
        set_saldo(interaction.user.id, saldo - preco)
        await interaction.followup.send(f"Pago com saldo. Restam R$ {get_saldo(interaction.user.id):.2f}", embed=embed_sala(sala, m), ephemeral=True)
        return

    chave = str(pix().get("chave") or "")
    if preco <= 0 or not chave or chave.startswith("sua-chave"):
        if not is_owner(interaction.user):
            await interaction.response.send_message("PIX ainda não configurado no painel. Pede saldo a um dono.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            sala = await criar_sala_tcp(m, interaction.user.display_name)
        except Exception as e:
            await interaction.followup.send(f"TCP fora: {e}", ephemeral=True)
            return
        await interaction.followup.send(embed=embed_sala(sala, m), ephemeral=True)
        return

    pid = novo_txid()
    PEDIDOS[pid] = {"user_id": interaction.user.id, "modo": m, "channel_id": interaction.channel_id, "ts": time.time()}
    e = discord.Embed(title="Pagamento PIX", color=0xE50914)
    e.add_field(name="Modo", value=MODOS[m]["label"], inline=True)
    e.add_field(name="Valor", value=f"R$ {preco:.2f}", inline=True)
    e.add_field(name="Seu saldo", value=f"R$ {saldo:.2f}", inline=True)
    e.add_field(name="Copia e cola", value=f"```{pix_copia_cola(pid)}```", inline=False)
    e.set_footer(text="Paga e clica em Já paguei — ou pede saldo a um dono (/setarsaldo).")
    await interaction.response.send_message(embed=e, view=PedidoView(pid), ephemeral=True)


@bot.tree.command(name="saldo", description="Ver teu saldo de salas")
async def cmd_saldo(interaction: discord.Interaction, usuario: discord.User | None = None):
    alvo = usuario if usuario and is_owner(interaction.user) else interaction.user
    await interaction.response.send_message(f"Saldo de <@{alvo.id}>: **R$ {get_saldo(alvo.id):.2f}**", ephemeral=True)


@bot.tree.command(name="setarsaldo", description="Definir saldo de um usuário (só dono)")
@app_commands.describe(usuario="Discord da pessoa", quantidade="Valor em R$ (ex: 20)")
@owner_only()
async def cmd_setarsaldo(interaction: discord.Interaction, usuario: discord.User, quantidade: float):
    v = set_saldo(usuario.id, quantidade)
    await interaction.response.send_message(f"Saldo de <@{usuario.id}> agora é **R$ {v:.2f}**", ephemeral=True)


@bot.tree.command(name="sala_admin", description="Criar sala na hora (só dono)")
@app_commands.choices(modo=[
    app_commands.Choice(name="CS 4v4", value="cs"),
    app_commands.Choice(name="BR", value="br"),
])
@owner_only()
async def cmd_sala_admin(interaction: discord.Interaction, modo: app_commands.Choice[str]):
    await interaction.response.defer(ephemeral=True)
    try:
        sala = await criar_sala_tcp(modo.value, interaction.user.display_name)
    except Exception as e:
        await interaction.followup.send(f"TCP fora: {e}", ephemeral=True)
        return
    await interaction.followup.send(embed=embed_sala(sala, modo.value))


@bot.tree.command(name="salas", description="Listar salas Discord (só dono)")
@owner_only()
async def cmd_salas(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    try:
        data = await tcp_json("GET", "/bot/rooms")
    except Exception as e:
        await interaction.followup.send(f"TCP fora: {e}", ephemeral=True)
        return
    rooms = data.get("rooms") or []
    if not rooms:
        await interaction.followup.send("Nenhuma sala Discord aberta.")
        return
    lines = [f"`{r['id']}` senha `{r['password']}` · {r['players']}/{r['max_players']} · modo {r['game_mode']}" for r in rooms]
    await interaction.followup.send("\n".join(lines)[:1900])


@bot.tree.command(name="fechar", description="Fechar sala pelo ID (só dono)")
@owner_only()
async def cmd_fechar(interaction: discord.Interaction, sala_id: str):
    await interaction.response.defer(ephemeral=True)
    try:
        await tcp_json("DELETE", f"/bot/rooms/{sala_id.strip()}")
    except Exception as e:
        await interaction.followup.send(f"Não fechou: {e}", ephemeral=True)
        return
    await interaction.followup.send(f"Sala `{sala_id}` fechada.")


# ---------- Painel web ----------

def panel_ok(request: web.Request) -> bool:
    tok = request.cookies.get("rz_panel") or ""
    return tok in PANEL_SESS


def login_html(err=""):
    e = f'<div class="err">{err}</div>' if err else ""
    return f"""<!doctype html><html><head><meta charset=utf-8><title>Painel bot</title>
<style>
body{{margin:0;font-family:system-ui;background:#000;color:#f3f3f3;display:grid;place-items:center;min-height:100vh}}
form{{background:#120406;border:1px solid #2b0d10;padding:28px;border-radius:14px;width:320px}}
input{{width:100%;padding:10px;margin:8px 0 16px;background:#0c0c0c;border:1px solid #2b0d10;color:#fff;border-radius:8px}}
button{{width:100%;padding:10px;background:#e50914;border:0;color:#fff;border-radius:8px;font-weight:700;cursor:pointer}}
.err{{color:#ff6b73;margin-bottom:10px}}
</style></head><body><form method=post action=/login>
<h2>Painel do bot</h2>{e}
<label>Senha</label><input type=password name=password autofocus>
<button>Entrar</button></form></body></html>"""


def dash_html():
    p = pix()
    donos = "\n".join(CFG.get("owners") or [])
    saldos = load_saldos()
    linhas = "".join(f"<tr><td>{k}</td><td>R$ {float(v):.2f}</td></tr>" for k, v in saldos.items()) or "<tr><td colspan=2>Nenhum saldo</td></tr>"
    tok = str(CFG.get("token") or "")
    tok_mask = (tok[:12] + "…" + tok[-6:]) if len(tok) > 20 else "••••"
    return f"""<!doctype html><html><head><meta charset=utf-8><title>Painel bot</title>
<style>
body{{margin:0;background:#000;color:#f3f3f3;font-family:system-ui}}
.wrap{{max-width:920px;margin:0 auto;padding:24px}}
h1{{color:#e50914}} h2{{font-size:16px;margin:28px 0 10px}}
label{{display:block;font-size:12px;color:#a8989a;margin-top:10px}}
input,textarea{{width:100%;padding:8px;background:#0c0c0c;border:1px solid #2b0d10;color:#fff;border-radius:8px}}
button,.btn{{background:#e50914;color:#fff;border:0;padding:10px 16px;border-radius:8px;cursor:pointer;font-weight:700}}
.card{{background:#120406;border:1px solid #2b0d10;border-radius:14px;padding:16px;margin:12px 0}}
table{{width:100%;border-collapse:collapse}} td,th{{padding:8px;border-bottom:1px solid #2b0d10;text-align:left}}
.row{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}
.muted{{color:#a8989a;font-size:13px}}
</style></head><body><div class=wrap>
<h1>Painel do bot de salas</h1>
<p class=muted>Altera donos, PIX, nome, foto, token e saldos. Salva em config.json.</p>
<form method=post action=/save class=card>
<h2>Bot</h2>
<div class=row>
<div><label>Bot ID</label><input name=bot_id value="{CFG.get('bot_id') or ''}"></div>
<div><label>Nome do bot</label><input name=bot_name value="{CFG.get('bot_name') or ''}"></div>
</div>
<label>Token</label><input name=token value="{CFG.get('token') or ''}" type=password>
<div class=muted>Atual: {tok_mask}</div>
<label>Donos (um ID Discord por linha)</label>
<textarea name=owners rows=4>{donos}</textarea>
<h2>TCP</h2>
<div class=row>
<div><label>tcp_api</label><input name=tcp_api value="{CFG.get('tcp_api') or ''}"></div>
<div><label>tcp_secret</label><input name=tcp_secret value="{CFG.get('tcp_secret') or ''}"></div>
</div>
<h2>PIX</h2>
<div class=row>
<div><label>Chave PIX</label><input name=pix_chave value="{p.get('chave') or ''}"></div>
<div><label>Valor da sala (R$)</label><input name=pix_valor value="{p.get('valor') or 0}"></div>
</div>
<div class=row>
<div><label>Nome no PIX</label><input name=pix_nome value="{p.get('nome') or ''}"></div>
<div><label>Cidade</label><input name=pix_cidade value="{p.get('cidade') or ''}"></div>
</div>
<label>Senha do painel</label><input name=panel_password type=password placeholder="deixe vazio pra não mudar">
<p><button>Salvar config</button></p>
</form>
<form method=post action=/avatar enctype=multipart/form-data class=card>
<h2>Foto do bot</h2>
<input type=file name=foto accept=image/png,image/jpeg,image/gif,image/webp>
<p><button>Enviar foto</button></p>
</form>
<form method=post action=/saldo class=card>
<h2>Setar saldo</h2>
<div class=row>
<div><label>ID Discord</label><input name=uid placeholder=740718333195714660></div>
<div><label>Valor R$</label><input name=valor placeholder=20></div>
</div>
<p><button>Definir saldo</button></p>
</form>
<div class=card>
<h2>Saldos</h2>
<table><tr><th>User ID</th><th>Saldo</th></tr>{linhas}</table>
</div>
<p><a class=btn href=/logout>Sair</a></p>
</div></body></html>"""


async def panel_index(request: web.Request):
    if not panel_ok(request):
        return web.Response(text=login_html(), content_type="text/html")
    return web.Response(text=dash_html(), content_type="text/html")


async def panel_login(request: web.Request):
    form = await request.post()
    pw = str(form.get("password") or "")
    if pw and pw == str(CFG.get("panel_password") or ""):
        tok = secrets.token_hex(16)
        PANEL_SESS.add(tok)
        resp = web.HTTPFound("/")
        resp.set_cookie("rz_panel", tok, httponly=True, max_age=12 * 3600)
        return resp
    return web.Response(text=login_html("Senha errada"), content_type="text/html")


async def panel_logout(request: web.Request):
    tok = request.cookies.get("rz_panel")
    if tok:
        PANEL_SESS.discard(tok)
    resp = web.HTTPFound("/")
    resp.del_cookie("rz_panel")
    return resp


async def panel_save(request: web.Request):
    if not panel_ok(request):
        return web.HTTPFound("/")
    form = await request.post()
    cfg = dict(CFG)
    cfg["bot_id"] = str(form.get("bot_id") or "").strip()
    cfg["bot_name"] = str(form.get("bot_name") or "").strip()
    tok = str(form.get("token") or "").strip()
    if tok:
        cfg["token"] = tok
    cfg["tcp_api"] = str(form.get("tcp_api") or "").strip()
    cfg["tcp_secret"] = str(form.get("tcp_secret") or "").strip()
    raw_owners = str(form.get("owners") or "")
    cfg["owners"] = [ln.strip() for ln in raw_owners.replace(",", "\n").splitlines() if ln.strip()]
    cfg["pix"] = {
        "chave": str(form.get("pix_chave") or "").strip(),
        "nome": str(form.get("pix_nome") or "RZIM").strip(),
        "cidade": str(form.get("pix_cidade") or "SAO PAULO").strip(),
        "valor": float(str(form.get("pix_valor") or "0") or 0),
    }
    npw = str(form.get("panel_password") or "").strip()
    if npw:
        cfg["panel_password"] = npw
    save_cfg(cfg)
    apply_cfg(cfg)
    nome = str(cfg.get("bot_name") or "").strip()
    if nome and bot.user and bot.user.name != nome:
        try:
            await bot.user.edit(username=nome)
        except Exception:
            pass
    return web.HTTPFound("/")


async def panel_avatar(request: web.Request):
    if not panel_ok(request):
        return web.HTTPFound("/")
    form = await request.post()
    up = form.get("foto")
    if not up or not getattr(up, "file", None):
        return web.HTTPFound("/")
    data = up.file.read()
    if not data or len(data) > 8_000_000:
        return web.HTTPFound("/")
    try:
        await bot.user.edit(avatar=data)
    except Exception as e:
        print("avatar:", e)
    return web.HTTPFound("/")


async def panel_saldo(request: web.Request):
    if not panel_ok(request):
        return web.HTTPFound("/")
    form = await request.post()
    try:
        uid = int(str(form.get("uid") or "0").strip())
        valor = float(str(form.get("valor") or "0"))
        if uid:
            set_saldo(uid, valor)
    except Exception:
        pass
    return web.HTTPFound("/")


async def start_panel():
    app = web.Application()
    app.router.add_get("/", panel_index)
    app.router.add_post("/login", panel_login)
    app.router.add_get("/logout", panel_logout)
    app.router.add_post("/save", panel_save)
    app.router.add_post("/avatar", panel_avatar)
    app.router.add_post("/saldo", panel_saldo)
    port = int(CFG.get("panel_port") or 7745)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    print(f"Painel em http://0.0.0.0:{port}")


def main():
    apply_cfg(load_cfg())
    token = str(CFG.get("token") or "").strip()
    if not token or token.startswith("COLE_"):
        raise SystemExit("Token vazio no config.json")
    if not owners():
        raise SystemExit("Nenhum dono no config.json")
    bid = str(CFG.get("bot_id") or "").strip()
    if bid:
        os.environ.setdefault("DISCORD_APPLICATION_ID", bid)
    bot.run(token)


if __name__ == "__main__":
    main()
