package tcp

import (
	"crypto/rand"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"
)

const botRoomTTL = 45 * time.Minute

type botRoomReq struct {
	Name       string `json:"name"`
	Password   string `json:"password"`
	GameMode   int    `json:"game_mode"`
	MapID      int    `json:"map_id"`
	MaxPlayers int    `json:"max_players"`
	GroupMode  int    `json:"group_mode"`
}

type botRoomOut struct {
	ID         int64  `json:"id"`
	Name       string `json:"name"`
	Password   string `json:"password"`
	GameMode   int    `json:"game_mode"`
	MapID      int    `json:"map_id"`
	Players    int    `json:"players"`
	MaxPlayers int    `json:"max_players"`
	State      int    `json:"state"`
	Owner      int64  `json:"owner"`
}

func (r *CustomRoom) botJSON() botRoomOut {
	return botRoomOut{
		ID: r.RoomID, Name: r.Name, Password: r.Password,
		GameMode: r.GameMode, MapID: r.MapID,
		Players: len(r.Players), MaxPlayers: r.MaxPlayers,
		State: r.State, Owner: r.CreatorID,
	}
}

func (s *Server) startBotAPI() {
	addr := strings.TrimSpace(s.Cfg.BotAPIAddr)
	if addr == "" || addr == "off" || addr == "0" {
		log.Printf("[ROOM-BOT] API desligada (BOT_API_ADDR vazio)")
		return
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/bot/rooms", s.botAuth(s.handleBotRooms))
	mux.HandleFunc("/bot/rooms/", s.botAuth(s.handleBotRoomOne))
	mux.HandleFunc("/bot/health", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"ok":true}`))
	})
	go s.expireBotRoomsLoop()
	go func() {
		log.Printf("[ROOM-BOT] API em http://%s  (secret no header X-Bot-Secret)", addr)
		if err := http.ListenAndServe(addr, mux); err != nil {
			log.Printf("[ROOM-BOT] HTTP: %v", err)
		}
	}()
}

func (s *Server) botAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		got := r.Header.Get("X-Bot-Secret")
		if got == "" {
			got = r.URL.Query().Get("secret")
		}
		if s.Cfg.BotAPISecret == "" || got != s.Cfg.BotAPISecret {
			http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
			return
		}
		next(w, r)
	}
}

func (s *Server) handleBotRooms(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		s.Rooms.mu.Lock()
		out := make([]botRoomOut, 0)
		for _, room := range s.Rooms.rooms {
			if room.BotOwned {
				out = append(out, room.botJSON())
			}
		}
		s.Rooms.mu.Unlock()
		_ = json.NewEncoder(w).Encode(map[string]any{"rooms": out})
	case http.MethodPost:
		var req botRoomReq
		body, _ := io.ReadAll(r.Body)
		if err := json.Unmarshal(body, &req); err != nil {
			http.Error(w, `{"error":"json"}`, http.StatusBadRequest)
			return
		}
		room, err := s.createBotRoom(req)
		if err != nil {
			http.Error(w, `{"error":"`+err.Error()+`"}`, http.StatusBadRequest)
			return
		}
		w.WriteHeader(http.StatusCreated)
		_ = json.NewEncoder(w).Encode(room.botJSON())
	default:
		http.Error(w, `{"error":"method"}`, http.StatusMethodNotAllowed)
	}
}

func (s *Server) handleBotRoomOne(w http.ResponseWriter, r *http.Request) {
	idStr := strings.TrimPrefix(r.URL.Path, "/bot/rooms/")
	idStr = strings.Trim(idStr, "/")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || id <= 0 {
		http.Error(w, `{"error":"id"}`, http.StatusBadRequest)
		return
	}
	s.Rooms.mu.Lock()
	room := s.Rooms.rooms[id]
	if room == nil || !room.BotOwned {
		s.Rooms.mu.Unlock()
		http.Error(w, `{"error":"not_found"}`, http.StatusNotFound)
		return
	}
	switch r.Method {
	case http.MethodGet:
		out := room.botJSON()
		s.Rooms.mu.Unlock()
		_ = json.NewEncoder(w).Encode(out)
	case http.MethodDelete:
		delete(s.Rooms.rooms, id)
		s.Rooms.mu.Unlock()
		log.Printf("[ROOM-BOT] sala %d fechada pela API", id)
		_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "id": id})
	default:
		s.Rooms.mu.Unlock()
		http.Error(w, `{"error":"method"}`, http.StatusMethodNotAllowed)
	}
}

func (s *Server) createBotRoom(req botRoomReq) (*CustomRoom, error) {
	name := strings.TrimSpace(req.Name)
	if name == "" {
		name = "Sala Discord"
	}
	pass := strings.TrimSpace(req.Password)
	if pass == "" {
		pass = randomRoomCode()
	}
	gm := req.GameMode
	if gm == 0 {
		gm = 15
	}
	mapID := req.MapID
	if mapID == 0 {
		mapID = 1
	}
	maxMem := req.MaxPlayers
	if maxMem <= 0 {
		if gm == 15 {
			maxMem = 8
		} else {
			maxMem = 50
		}
	}
	group := req.GroupMode
	if gm == 15 && group == 0 {
		group = 3
	}

	room := &CustomRoom{
		Name: name, Password: pass,
		CreatorID: 0, CreatorNm: "Discord", CreatorRole: 100,
		MapID: mapID, GameMode: gm, GroupMode: group,
		Players: nil, Spectators: nil, Invited: map[int64]time.Time{},
		MaxPlayers: maxMem, MaxSpectators: 6,
		BotOwned: true, CreatedAt: time.Now(),
	}
	s.Rooms.mu.Lock()
	room.RoomID = s.Rooms.nextID()
	s.Rooms.rooms[room.RoomID] = room
	s.Rooms.mu.Unlock()
	log.Printf("[ROOM-BOT] criada id=%d senha=%s modo=%d max=%d", room.RoomID, room.Password, gm, maxMem)
	return room, nil
}

func (s *Server) expireBotRoomsLoop() {
	t := time.NewTicker(60 * time.Second)
	defer t.Stop()
	for range t.C {
		now := time.Now()
		s.Rooms.mu.Lock()
		for id, room := range s.Rooms.rooms {
			if !room.BotOwned || room.State >= 1 {
				continue
			}
			if len(room.Players) > 0 {
				continue
			}
			if !room.CreatedAt.IsZero() && now.Sub(room.CreatedAt) > botRoomTTL {
				delete(s.Rooms.rooms, id)
				log.Printf("[ROOM-BOT] sala %d expirou (45 min vazia)", id)
			}
		}
		s.Rooms.mu.Unlock()
	}
}

func randomRoomCode() string {
	var b [3]byte
	if _, err := rand.Read(b[:]); err != nil {
		return "4821"
	}
	n := int(b[0])<<16 | int(b[1])<<8 | int(b[2])
	return strconv.Itoa(1000 + n%9000)
}
