# Patches no tcp-server (Go)

Arquivo novo: `internal/tcp/customroom_botapi.go` (API HTTP local para o bot Discord).

Os trechos abaixo foram aplicados nos arquivos já existentes do lobby TCP.

## 1. `internal/config/config.go`

Novos campos no `Config`:

```go
// Bot Discord: HTTP local pra criar salas custom (salas_discord/bot.py).
// Vazio / off = API desligada. Secret tem que bater com config.json do bot.
BotAPIAddr   string
BotAPISecret string
```

Leitura no `Load()`:

```go
BotAPIAddr:   get("BOT_API_ADDR", "127.0.0.1:7744"),
BotAPISecret: get("BOT_API_SECRET", "troca-essa-chave"),
```

## 2. `internal/tcp/server.go`

No `ListenAndServe`, depois da limpeza de nicks:

```go
s.startBotAPI()
```

## 3. `internal/tcp/customroom.go`

Flag e timestamp na struct `CustomRoom`:

```go
BotOwned  bool      // criada pelo Discord: vazia permanece até TTL; 1º jogador vira dono
CreatedAt time.Time
```

Join: se a sala é `BotOwned` e ainda não tem `CreatorID`, o primeiro jogador vira dono e já entra ready.

Leave (sala bot):

- Dono sai com gente dentro → transfere o dono para o próximo da lista (não dismiss).
- Sala fica vazia → `CreatorID` volta a 0, o código/senha Discord continua válido.
- Só expira depois de 45 minutos vazia (loop em `customroom_botapi.go`).
- Sala comum (não bot) mantém o comportamento antigo: dono sair ou ficar vazia fecha a sala.

## API HTTP (loopback)

Bind: `BOT_API_ADDR` (produção: `127.0.0.1:7744`).  
Auth: header `X-Bot-Secret` igual a `BOT_API_SECRET`.

| Método | Rota | Função |
|--------|------|--------|
| GET | `/bot/health` | `{ "ok": true }` |
| GET | `/bot/rooms` | lista salas `BotOwned` |
| POST | `/bot/rooms` | cria sala (CS 4v4 ou BR) |
| GET | `/bot/rooms/{id}` | detalhes |
| DELETE | `/bot/rooms/{id}` | fecha |

Body do POST:

```json
{
  "name": "Discord · nick",
  "game_mode": 15,
  "map_id": 1,
  "max_players": 8,
  "group_mode": 3
}
```

- `game_mode` 15 = CS Rank 4v4 (`group_mode` 3)
- `game_mode` 1 = BR Classic (`max_players` 50)
